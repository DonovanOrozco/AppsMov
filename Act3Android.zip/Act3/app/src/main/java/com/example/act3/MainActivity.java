package com.example.act3;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Matrix;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    private ImageView calaca;
    private Button Zoom_Mas, Zoom_Menos, Rotar;

    private float scale = 1f;
    private float angulo = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calaca = findViewById(R.id.calaca);
        Zoom_Mas = findViewById(R.id.Zoom_Mas);
        Zoom_Menos = findViewById(R.id.Zoom_Menos);
        Rotar = findViewById(R.id.Rotar);

        Zoom_Mas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Zoom_Mas(v);
            }
        });

        Zoom_Menos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Zoom_Menos(v);
            }
        });

        Rotar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rotar(v);
            }
        });


    }
    public void Zoom_Mas (View view){
        scale += 0.1f;
        calaca.setScaleX(scale);
        calaca.setScaleY(scale);
    }

    public void Zoom_Menos (View view){
        scale -= 0.1f;
        calaca.setScaleX(scale);
        calaca.setScaleY(scale);
    }

    public void Rotar (View view){
        angulo += 10f;
        calaca.setRotation(angulo);
    }
}