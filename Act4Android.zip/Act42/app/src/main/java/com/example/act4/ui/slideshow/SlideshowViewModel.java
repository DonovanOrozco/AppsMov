package com.example.act4.ui.slideshow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SlideshowViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public SlideshowViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Kendrick Lamar Duckworth es un rapero, compositor y productor discográfico estadounidense. Lamar es ampliamente considerado como uno de los mejores raperos de todos los tiempos y uno de los mejores nacidos en Compton.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}