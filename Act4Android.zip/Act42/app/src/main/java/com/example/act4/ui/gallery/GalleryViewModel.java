package com.example.act4.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    public int text;

    public GalleryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Kanye West es un rapero, productor, actor, diseñador y empresario estadounidense.\u200B Nacido en Atlanta y criado en Chicago, West ganó popularidad como productor musical para el sello Roc-A-Fella Records a principios de los años 2000, produciendo varios sencillos para artistas populares. Como lo son Jay Z o Travis Scott");
    }

    public LiveData<String> getText() {
        return mText;
    }
}