//
//  ViewController.swift
//  Act2
//
//  Created by Donovan Orozco Garcia on 26/01/24.
//

import UIKit

extension UIColor {
  static func random() -> UIColor {
    let red = CGFloat.random(in: 0...1)
    let green = CGFloat.random(in: 0...1)
    let blue = CGFloat.random(in: 0...1)
    return UIColor(red: red, green: green, blue: blue, alpha: 1)
  }
    
}


class ViewController: UIViewController {

  
    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet weak var Cambiar: UIButton!
    
    @IBOutlet weak var nombre: UITextField!
    
    override func viewDidLoad() {
       super.viewDidLoad()
        
       
    }


    
    
    @IBAction func Color(_ sender: Any) {
        view.backgroundColor = UIColor.random()
    }
    
 
    @IBAction func Palabra(_ sender: Any) {
        let mensaje = "Eres mejor de lo que crees."
            
            let alert = UIAlertController(title: nil, message: mensaje, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            
            present(alert, animated: true, completion: nil)
    }
    
    @IBAction func Cambiar(_ sender: Any) {
            }
    
    @IBAction func nombre(_ sender: Any) {
    }

    
}

