import UIKit

class AddEditEmojiTableViewController: UITableViewController {
    
    var emoji: Emoji?

    @IBOutlet var nombreTextField: UITextField!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var codigoTextField: UITextField!
    @IBOutlet var saveButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let emoji = emoji {
            nombreTextField.text = emoji.nombre
            emailTextField.text = emoji.email
            codigoTextField.text = emoji.codigo
            title = "Edit Emoji"
        } else {
            title = "Add Emoji"
        }
        
        updateSaveButtonState()
    }
    
    init?(coder: NSCoder, emoji: Emoji?) {
        self.emoji = emoji
        super.init(coder: coder)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateSaveButtonState() {
        let nombreText = nombreTextField.text ?? ""
        let emailText = emailTextField.text ?? ""
        let codigoText = codigoTextField.text ?? ""
        saveButton.isEnabled = containsSingleEmoji(nombreText) && !nombreText.isEmpty && !emailText.isEmpty && !codigoText.isEmpty
    }
    
    @IBAction func textEditingChanged(_ sender: UITextField) {
        updateSaveButtonState()
    }
    
    func containsSingleEmoji(_ text: String) -> Bool {
        guard text.count == 1 else {
            return false
        }

        let isEmoji = text.unicodeScalars.first?.properties.isEmoji ?? false
        let isEmojiPresentation = text.unicodeScalars.first?.properties.isEmojiPresentation ?? false

        return isEmoji || isEmojiPresentation
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "saveUnwind" else { return }

        let nombre = nombreTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let codigo = codigoTextField.text ?? ""
        let symbol = emoji?.symbol
        let name = emoji?.name
        emoji = Emoji(nombre: nombre, email: email, codigo: codigo, symbol: symbol!, name: name ?? <#default value#>, description: description)
    }
}
