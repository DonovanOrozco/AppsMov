import Foundation

struct Emoji {
    var nombre: String
    var email: String
    var codigo: String
    var symbol: String
    var name: String
    var description: String
}
