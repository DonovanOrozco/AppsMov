package com.example.act6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    //Declaro los botones y los textviews para que asi puedan conectarse
    private EditText diaHoyEditText;
    private EditText CumpleEditText;
    private Button edadButton;
    private TextView resultadoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Le declaro las acciones para que puedan funcionar
        diaHoyEditText = findViewById(R.id.diahoy);
        CumpleEditText = findViewById(R.id.Cumple);
        edadButton = findViewById(R.id.edad);
        resultadoTextView =  findViewById(R.id.resultado);

        edadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edadButton();
            }
        });
    }


    private void edadButton() {
        //Aqui use un simple data fomat para poner como se debe de usar la fecha que seria, dia, mes, año
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {

            //Aqui se dan las fechas mediante lo que seleccione el usuario
            Date fechahoy = Calendar.getInstance().getTime();
            Date fechacumple = dateFormat.parse(CumpleEditText.getText().toString());

            //Se crearon estas variables para almacenar los datos de fecha que el usuario coloco
            Calendar calCumple = Calendar.getInstance();
            calCumple.setTime(fechacumple);

            Calendar calHoy = Calendar.getInstance();
            calHoy.setTime(fechahoy);

            //Se hace la operacion para así poder ver la edad del usuario
            int edadAnos = calHoy.get(Calendar.YEAR) - calCumple.get(Calendar.YEAR);
            int edadMeses = calHoy.get(Calendar.MONTH) - calCumple.get(Calendar.MONTH);
            int edadDias = calHoy.get(Calendar.DAY_OF_MONTH) - calCumple.get(Calendar.DAY_OF_MONTH);

            //Aqui se hace una correcion si hay valores negatvios en donde se resta un mes
            if (edadDias < 0) {
                edadMeses--;
                calHoy.add(Calendar.MONTH, -1); // Restar un mes
                edadDias += calHoy.getActualMaximum(Calendar.DAY_OF_MONTH); // Añadir los días del mes anterior
            }

            if (edadMeses < 0) {
                edadAnos--;
                edadMeses += 12;
            }

            //Se actualiza el textView con la info de la edad del usuario para que se pueda imprimir en pantalla 
            String resultado = "Edad: " + edadAnos + " años y " + edadMeses + " meses";
            resultadoTextView.setText(resultado);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

}