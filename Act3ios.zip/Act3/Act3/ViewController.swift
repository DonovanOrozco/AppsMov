//
//  ViewController.swift
//  Act3
//
//  Created by Donovan Orozco Garcia on 01/02/24.
//

import UIKit

//Aqui cree la clase pregunta ademas de definir todos los valores

class Pregunta {
    let pregunta: String
    let respuestas: [String]
    let Respuesta_Corr: Int
    
    init(pregunta: String, respuestas: [String], Respuesta_Corr: Int) {
        self.pregunta = pregunta
        self.respuestas = respuestas
        self.Respuesta_Corr = Respuesta_Corr
    }
}

class ViewController: UIViewController {
    
    //Se conectan los botones del main al codigo para tenerlos establecidos
    @IBOutlet weak var PreguntaLab: UILabel!
    @IBOutlet weak var Res1_Button: UIButton!
    @IBOutlet weak var Res2_Button: UIButton!
    @IBOutlet weak var Res3_Button: UIButton!
    @IBOutlet weak var Res4_Button: UIButton!
    
    //Aqui declare las variables para la logica y las vidas ademas del puntaje
    var preguntas: [Pregunta]!
    var currentQuestionIndex = 0
    var vidas = 3
    var puntaje = 0
    var respuestaSeleccionada: Int?

    override func viewDidLoad() {
        super.viewDidLoad()

        //Aqui defini las preguntas con sus respectivas respuestas
        preguntas = [
            Pregunta(pregunta: "Quien creo los Yeezy?", respuestas: ["Kanye West", "Travis Scott", "Taylor Swfit", "Drake"], Respuesta_Corr: 0),
            Pregunta(pregunta: "Cual es el ulitmo album de Ye?", respuestas: ["MBTDF", "Donda", "Yeezus", "Graduation"], Respuesta_Corr: 1),
        ]

        Siguiente_Pre()
    }

    //Aqui declare la funcion para la siguiente pregunta
    func Siguiente_Pre() {
        if currentQuestionIndex < preguntas.count {
            let pregunta = preguntas[currentQuestionIndex]

            PreguntaLab.text = pregunta.pregunta
            Res1_Button.setTitle(pregunta.respuestas[0], for: .normal)
            Res2_Button.setTitle(pregunta.respuestas[1], for: .normal)
            Res3_Button.setTitle(pregunta.respuestas[2], for: .normal)
            Res4_Button.setTitle(pregunta.respuestas[3], for: .normal)
        } else {
            let alertController = UIAlertController(title: "Fin del juego", message: "Tu puntaje fue de \(puntaje) puntos.", preferredStyle: .alert)
                  let actionReiniciar = UIAlertAction(title: "Reiniciar", style: .default) { _ in
                    self.vidas = 3
                    self.puntaje = 0
                    self.currentQuestionIndex = 0
                    self.Siguiente_Pre()
                  }
                  alertController.addAction(actionReiniciar)
                  present(alertController, animated: true, completion: nil)
        }
    }

    //Aqui conecte los botones para establecer como iban a funcionar y establecer alertas por si estas correcto o no
    @IBAction func answerButtonTapped(_ sender: UIButton) {
        let respuestaSeleccionada = sender.tag
        let correctAnswer = preguntas[currentQuestionIndex].Respuesta_Corr

        // Si la respuesta es correcta, pasar a la siguiente pregunta
        if respuestaSeleccionada == correctAnswer {
          puntaje += 1
          currentQuestionIndex += 1
          Siguiente_Pre()
        } else {
          vidas -= 1

          if vidas == 0 {
            // Mostrar mensaje de fin del juego
            let alertController = UIAlertController(title: "Fin del juego", message: "Has perdido todas tus vidas. Tu puntaje fue de \(puntaje) puntos.", preferredStyle: .alert)
            let actionReiniciar = UIAlertAction(title: "Reiniciar", style: .default) { _ in
              self.vidas = 3
              self.puntaje = 0
              self.currentQuestionIndex = 0
              self.Siguiente_Pre()
            }
            alertController.addAction(actionReiniciar)
            present(alertController, animated: true, completion: nil)
          } else {
            // Mostrar mensaje de respuesta incorrecta y repetir la pregunta
            let alertController = UIAlertController(title: "Incorrecto", message: "Lo siento, esa no es la respuesta correcta. Te quedan \(vidas) vidas.", preferredStyle: .alert)
            let actionReintentar = UIAlertAction(title: "Reintentar", style: .default) { _ in
              // No se hace nada, se repite la misma pregunta
            }
            alertController.addAction(actionReintentar)
            present(alertController, animated: true, completion: nil)
          }
        }
      }

}

