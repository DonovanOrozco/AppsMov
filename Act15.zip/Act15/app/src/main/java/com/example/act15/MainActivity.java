package com.example.act15;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerFrom, spinnerTo;
    EditText editTextAmount;
    Button buttonConvert;
    TextView textViewResult;

    double[] currencyValues = {1.0, 0.85, 0.73};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerFrom = findViewById(R.id.spinner1);
        spinnerTo = findViewById(R.id.spinner2);
        editTextAmount = findViewById(R.id.Cantidad);
        buttonConvert = findViewById(R.id.button_convertir);
        textViewResult = findViewById(R.id.result);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertCurrency();
            }
        });
    }

    private void convertCurrency() {
        int fromIndex = spinnerFrom.getSelectedItemPosition();
        int toIndex = spinnerTo.getSelectedItemPosition();

        double amount = Double.parseDouble(editTextAmount.getText().toString());
        double fromValue = currencyValues[fromIndex];
        double toValue = currencyValues[toIndex];

        double result = (amount / fromValue) * toValue;

        DecimalFormat df = new DecimalFormat("#.##");
        textViewResult.setText(df.format(result));
    }
}
