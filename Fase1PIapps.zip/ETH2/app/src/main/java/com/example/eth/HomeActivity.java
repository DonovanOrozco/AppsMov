package com.example.eth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {

    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home1);

        EditText clienteEditText = findViewById(R.id.caja_nombre_cliente);
        EditText clinicaEditText = findViewById(R.id.caja_clinica);
        EditText articuloEditText = findViewById(R.id.caja_articulo);
        EditText cantidadArticuloEditText = findViewById(R.id.caja_cantidad_articulo);
        Button registrarDatosButton = findViewById(R.id.btn_registrar_datos);
        Button limpiarCamposButton = findViewById(R.id.btn_limpiarcampos);
        Button cerrarSesionButton = findViewById(R.id.btn_cerrarsesion);
        LinearLayout linearLayoutRegistros = findViewById(R.id.linear_layout_registros);
        linearLayoutRegistros.setOrientation(LinearLayout.VERTICAL);

        registrarDatosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cliente = clienteEditText.getText().toString();
                String clinica = clinicaEditText.getText().toString();
                String articulo = articuloEditText.getText().toString();
                String cantidadArticulo = cantidadArticuloEditText.getText().toString();

                if (!cliente.isEmpty() && !clinica.isEmpty() && !articulo.isEmpty() && !cantidadArticulo.isEmpty()) {
                    // Obtiene el correo electrónico del usuario actual (el especialista)
                    String especialistaEmail = mAuth.getCurrentUser().getEmail();

                    // Extrae la parte del usuario del correo electrónico (antes del '@')
                    String especialistaUsername = especialistaEmail.split("@")[0];

                    // Genera un ID único para cada registro
                    String registroId = mDatabase.push().getKey();

                    // Obtiene la fecha y hora actuales
                    String fechaHoraRegistro = java.text.DateFormat.getDateTimeInstance().format(new Date());

                    // Crea un mapa con los datos a registrar
                    Map<String, Object> datos = new HashMap<>();
                    datos.put("cliente", cliente);
                    datos.put("clinica", clinica);
                    datos.put("articulo", articulo);
                    datos.put("cantidadArticulo", cantidadArticulo);
                    datos.put("fechaHoraRegistro", fechaHoraRegistro);

                    // Sube los datos a Firebase bajo el nodo del especialista actual
                    mDatabase.child("registros").child(especialistaUsername).child(cliente).child(registroId).updateChildren(datos)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        // Registro exitoso
                                        Toast.makeText(HomeActivity.this, "Datos registrados exitosamente.",
                                                Toast.LENGTH_SHORT).show();

                                        // Agrega el registro al ScrollView
                                        TextView registroTextView = new TextView(HomeActivity.this);
                                        registroTextView.setText("Cliente: " + cliente + ", Clínica: " + clinica + ", Artículo: " + articulo + ", Cantidad: " + cantidadArticulo);
                                        linearLayoutRegistros.addView(registroTextView);
                                    } else {
                                        // Si el registro falla, muestra un mensaje al usuario.
                                        Toast.makeText(HomeActivity.this, "Error al registrar los datos.",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                } else {
                    Toast.makeText(HomeActivity.this, "Por favor, rellene todos los campos.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        limpiarCamposButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Limpia los campos
                clienteEditText.setText("");
                clinicaEditText.setText("");
                articuloEditText.setText("");
                cantidadArticuloEditText.setText("");
            }
        });

        cerrarSesionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cierra la sesión en Firebase Authentication
                mAuth.signOut();

                // Limpia el ScrollView
                linearLayoutRegistros.removeAllViews();

                // Regresa a la interfaz login_activity
                Intent intent = new Intent(HomeActivity.this, login_activity.class);
                startActivity(intent);
                finish();
            }
        });

        //redirige a la vista de la base de datos

        Button verDbButton = findViewById(R.id.btn_ver_db);
        verDbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, DatosActivity.class);
                startActivity(intent);
            }
        });



    }
}

