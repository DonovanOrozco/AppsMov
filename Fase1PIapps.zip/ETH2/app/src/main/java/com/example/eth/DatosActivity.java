package com.example.eth;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class DatosActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_db);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        SearchView searchView = findViewById(R.id.search_view);
        LinearLayout linearLayoutDatos = findViewById(R.id.linear_layout_datos);
        Button cerrarSesionButton = findViewById(R.id.btn_cerrarsesion);
        Button registrarButton = findViewById(R.id.btn_registrar);

        // Implementa la funcionalidad de búsqueda
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Aquí puedes implementar la lógica para buscar en la base de datos según la consulta
                // Por ahora, solo limpiamos el LinearLayout y buscamos los datos que coincidan con la consulta
                linearLayoutDatos.removeAllViews();
                buscarDatos(query, linearLayoutDatos);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Aquí puedes implementar la lógica para buscar en la base de datos a medida que el usuario escribe en el campo de búsqueda
                // Por ahora, solo limpiamos el LinearLayout y buscamos los datos que coincidan con la consulta
                linearLayoutDatos.removeAllViews();
                buscarDatos(newText, linearLayoutDatos);
                return false;
            }
        });

        // Implementa la funcionalidad del botón de cerrar sesión
        cerrarSesionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                // Limpia el ScrollView
                linearLayoutDatos.removeAllViews();
                // Aquí puedes implementar la lógica para regresar a la pantalla de inicio de sesión
                Intent intent = new Intent(DatosActivity.this, login_activity.class);
                startActivity(intent);
                finish();
            }
        });

        // Implementa la funcionalidad del botón de registrar
        registrarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes implementar la lógica para abrir la actividad de registro de datos
                Intent intent = new Intent(DatosActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        // Aquí puedes implementar la lógica para buscar todos los datos de la base de datos y mostrarlos en el LinearLayout
        buscarDatos("", linearLayoutDatos);
    }

    private void buscarDatos(String query, LinearLayout linearLayoutDatos) {
        // Aquí puedes implementar la lógica para buscar en la base de datos según la consulta
        // Por ahora, solo buscamos todos los datos y los mostramos en el LinearLayout
        mDatabase.child("registros").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot especialistaSnapshot : dataSnapshot.getChildren()) {
                    String especialista = especialistaSnapshot.getKey();
                    for (DataSnapshot clienteSnapshot : especialistaSnapshot.getChildren()) {
                        String cliente = clienteSnapshot.getKey();
                        for (DataSnapshot registroSnapshot : clienteSnapshot.getChildren()) {
                            Map<String, Object> registro = (Map<String, Object>) registroSnapshot.getValue();

                            // Agrega el registro al LinearLayout
                            TextView registroTextView = new TextView(DatosActivity.this);
                            registroTextView.setText("Especialista: " + especialista + ", Cliente: " + cliente + ", Clínica: " + registro.get("clinica") + ", Artículo: " + registro.get("articulo") + ", Cantidad: " + registro.get("cantidadArticulo"));
                            linearLayoutDatos.addView(registroTextView);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Si la búsqueda falla, muestra un mensaje al usuario.
                Toast.makeText(DatosActivity.this, "Error al buscar los datos.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
