package com.example.eth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login_activity extends AppCompatActivity {

    FirebaseAuth mAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText usuarioEditText = findViewById(R.id.caja_usuario);
        EditText contraseñaEditText = findViewById(R.id.caja_pwd);
        Button loginButton = findViewById(R.id.btn_ingresar);
        Button registerButton = findViewById(R.id.btn_registrar); //quitar después de registrar a todos los usuarios
        Button salirButton = findViewById(R.id.btn_salirlogin);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = usuarioEditText.getText().toString();
                String contraseña = contraseñaEditText.getText().toString();

                if (!usuario.isEmpty() && !contraseña.isEmpty()) {
                    loginUser(usuario, contraseña);
                } else {
                    Toast.makeText(login_activity.this, "Por favor, rellene todos los campos.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = usuarioEditText.getText().toString();
                String contraseña = contraseñaEditText.getText().toString();
                if (!usuario.isEmpty() && !contraseña.isEmpty()) {
                    registerUser(usuario, contraseña);
                } else {
                    Toast.makeText(login_activity.this, "Por favor, rellene todos los campos.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        salirButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity(); // Esto cierra todas las actividades y sale de la aplicación
            }
        });
    }

    private void loginUser(String usuario, String contraseña) {
        mAuth.signInWithEmailAndPassword(usuario, contraseña)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Inicio de sesión exitoso
                            FirebaseUser user = mAuth.getCurrentUser();
                            // Navega a la siguiente actividad
                            Intent intent = new Intent(login_activity.this, HomeActivity.class);
                            startActivity(intent);
                            finish(); // Esto cierra la actividad de inicio de sesión
                        } else {
                            // Si el inicio de sesión falla, muestra un mensaje al usuario.
                            Toast.makeText(login_activity.this, "El usuario/contraseña no existen o son incorrectos.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void registerUser(String usuario, String contraseña) {
        mAuth.createUserWithEmailAndPassword(usuario, contraseña)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Registro exitoso
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(login_activity.this, "Registro exitoso.",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            // Si el registro falla, muestra un mensaje al usuario.
                            Toast.makeText(login_activity.this, "Error al registrarse, rellene bien los campos.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}

