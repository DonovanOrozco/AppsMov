//
//  PerfilController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 02/04/24.
//

import UIKit
import CoreData

class PerfilController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!

    var datos: [NSManagedObject] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        usernameLabel.text = "Donovan"

        tableView.dataSource = self
        tableView.delegate = self

        cargarDatos()
    }

    func cargarDatos() {
        let context = CoreDataStack.shared.context
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Artist")

        do {
            datos = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print("No se pudo cargar los datos. \(error), \(error.userInfo)")
        }
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datos.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        let dato = datos[indexPath.row]
        cell.textLabel?.text = dato.value(forKeyPath: "name") as? String

        return cell
    }
}
