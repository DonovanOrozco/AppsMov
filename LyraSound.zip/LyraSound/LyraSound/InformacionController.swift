//
//  InformacionController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 03/04/24.
//

import UIKit
import CoreData

class InformacionController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var gender: UITextField!
    
    @IBOutlet weak var information: UITextField!
    
    @IBOutlet weak var ID: UITextField!
    
    
    @IBAction func guardar(_ sender: Any) {
        let context = CoreDataStack.shared.context
                let nuevaEntidad = NSEntityDescription.insertNewObject(forEntityName: "Artist", into: context)

                nuevaEntidad.setValue(name.text, forKey: "name")
                nuevaEntidad.setValue(Int(ID.text ?? ""), forKey: "id")
                nuevaEntidad.setValue(gender.text, forKey: "genere")
                nuevaEntidad.setValue(information.text, forKey: "info")

                do {
                    try context.save()
                    print("Artista guardado exitosamente.")
                } catch let error as NSError {
                    print("No se pudo guardar. \(error), \(error.userInfo)")
                }
    }
    
}
