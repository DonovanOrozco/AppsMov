//
//  Artis.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 08/05/24.
//

struct Artis: Codable {
    var symbol: String
    var nombre: String
    var descripcion: String
    var bsong: String
}
