//
//  ArtistasTableViewCell.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 08/05/24.
//

import UIKit

class ArtistasTableViewCell: UITableViewCell {

    @IBOutlet var symbolLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func update(with artista: Artis) {
        symbolLabel.text = artista.symbol
        nameLabel.text = artista.nombre
        descriptionLabel.text = artista.descripcion
    }

}
