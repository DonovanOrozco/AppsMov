//
//  AnadirArtistasViewController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 08/05/24.
//

import UIKit

class AnadirArtistasViewController: UITableViewController {
    
    var artista: Artis?

    @IBOutlet var symbolTextField: UITextField!
    @IBOutlet var nameTextField: UITextField!
    @IBOutlet var descriptionTextField: UITextField!
    @IBOutlet var usageTextField: UITextField!
    
    @IBOutlet var saveButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let artista = artista {
            symbolTextField.text = artista.symbol
            nameTextField.text = artista.nombre
            descriptionTextField.text = artista.descripcion
            usageTextField.text = artista.bsong
            title = "Editar Artista"
        } else {
            title = "Añadir Artista"
        }
        
        updateSaveButtonState()
    }
    
    init?(coder: NSCoder, artista: Artis?) {
        self.artista = artista
        super.init(coder: coder)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateSaveButtonState() {
        let nameText = nameTextField.text ?? ""
        let descriptionText = descriptionTextField.text ?? ""
        let usageText = usageTextField.text ?? ""
        saveButton.isEnabled = !nameText.isEmpty && !descriptionText.isEmpty && !usageText.isEmpty
    }
    
    @IBAction func textEditingChanged(_ sender: UITextField) {
        updateSaveButtonState()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "saveUnwind" else { return }

        let symbol = symbolTextField.text ?? ""
        let name = nameTextField.text ?? ""
        let description = descriptionTextField.text ?? ""
        let usage = usageTextField.text ?? ""
        artista = Artis(symbol: symbol, nombre: name, descripcion: description, bsong: usage)
    }
}

