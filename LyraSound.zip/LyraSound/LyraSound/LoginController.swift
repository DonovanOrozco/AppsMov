//
//  LoginController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 02/04/24.
//

import UIKit

class LoginController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func registerButtonTapped(_ sender: Any) {
        let email = emailTextField.text ?? ""
        let username = usernameTextField.text ?? ""
        let password = passwordTextField.text ?? ""

        let isValid = validateFields(email: email, username: username, password: password)
        if isValid {
            
            registerUser(email: email, username: username, password: password)

            let tabBarController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
            present(tabBarController, animated: true, completion: nil)
            
        } else {
            showAlert(withTitle: "Campos incompletos", message: "Por favor, completa todos los campos para registrarte.")
        }
    }

    private func validateFields(email: String, username: String, password: String) -> Bool {
        return !email.isEmpty && !username.isEmpty && !password.isEmpty
    }

    private func registerUser(email: String, username: String, password: String) {
        // Aquí debes implementar la lógica real para registrar al usuario en la base de datos
        // Por ahora, simplemente simulemos que se registra correctamente
        print("Usuario registrado exitosamente")
    }

    private func showAlert(withTitle title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
