import UIKit

class ArtistasTablaViewController: UITableViewController {
    
    var artistas: [Artis] = [
        Artis(symbol: "🦔", nombre: "Kendr", descripcion: "Descripción del Artista1", bsong: "Canción del Artista1"),
        Artis(symbol: "🥷🏻", nombre: "Artista1", descripcion: "Descripción del Artista1", bsong: "Canción del Artista1"),
        Artis(symbol: "🧛🏻", nombre: "Artista1", descripcion: "Descripción del Artista1", bsong: "Canción del Artista1")]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = editButtonItem
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44.0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    
    @IBSegueAction func AnadirArtistasViewController(_ coder: NSCoder, sender: Any?) -> AnadirArtistasViewController? {
        if let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) {
            let artistaToEdit = artistas[indexPath.row]
            return LyraSound.AnadirArtistasViewController(coder: coder, artista: artistaToEdit)
        } else {
            // Agregar nuevo artista
            return LyraSound.AnadirArtistasViewController(coder: coder, artista: nil)
        }
    }
    
    @IBAction func unwindToArtistasTableView(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind",
            let sourceViewController = segue.source as? AnadirArtistasViewController,
            let artista = sourceViewController.artista else { return }
        
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            artistas[selectedIndexPath.row] = artista
            tableView.reloadRows(at: [selectedIndexPath], with: .none)
        } else {
            let newIndexPath = IndexPath(row: artistas.count, section: 0)
            artistas.append(artista)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return artistas.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ArtistaCell", for: indexPath) as! ArtistasTableViewCell

        let artista = artistas[indexPath.row]

        cell.update(with: artista)
        cell.showsReorderControl = true

        return cell
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            artistas.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
        let movedArtista = artistas.remove(at: fromIndexPath.row)
        artistas.insert(movedArtista, at: to.row)
    }

    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
}
