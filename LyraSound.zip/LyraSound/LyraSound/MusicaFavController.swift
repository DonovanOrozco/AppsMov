//
//  MusicaFavController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 03/04/24.
//

import UIKit

class MusicaFavController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
   
}
