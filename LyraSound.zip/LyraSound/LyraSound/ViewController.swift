//
//  ViewController.swift
//  LyraSound
//
//  Created by Donovan Orozco Garcia on 31/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    @IBAction func logInButtonTapped(_ sender: Any) {

        let username = usernameTextField.text ?? ""
        let password = passwordTextField.text ?? ""


        if validateUser(username: username, password: password) {
    
                    let tabBarController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
                    present(tabBarController, animated: true, completion: nil)
                } else {
                    showAlert(message: "Usuario o contraseña incorrectos")
                }
    }

    @IBAction func signInButtonTapped(_ sender: Any) {
        
        let registerViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RegistrarSceen")

            present(registerViewController, animated: true, completion: nil)
        }
    

    func validateUser(username: String, password: String) -> Bool {

        return username == "donovan" && password == "1234"
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}
