package com.example.act12;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] imageIds = { R.drawable.gallo, R.drawable.ine, R.drawable.wera};

        ViewPager viewPager = findViewById(R.id.viewPager);
        ImagePageAdapter adapter = new ImagePageAdapter(this, imageIds);
        viewPager.setAdapter(adapter);
    }
}
